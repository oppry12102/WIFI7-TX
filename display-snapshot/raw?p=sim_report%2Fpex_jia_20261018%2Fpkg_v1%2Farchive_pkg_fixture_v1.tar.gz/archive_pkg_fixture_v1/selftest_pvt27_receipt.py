#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""selftest_pvt27_receipt.py — §五 四件套装配器自测（合成台账 + 现役停线态负对照）

测 4 态，证明装配器不是恒判 COMPLETE：
  T1 COMPLETE ：合成一套齐件（pipeline/op_gate/tran/ledger/susp 表）→ 状态 COMPLETE，rc=0
  T2 缺 27 角：同 T1 但无台账 → INCOMPLETE，missing 列出「27 角台账」，rc=3
  T3 缺门2   ：同 T1 但无 tran json → INCOMPLETE，缺件列名，rc=3
  T4 角级残缺：台账在但 1 角 error → INCOMPLETE，missing 含「逐角判读不全 26/27」，rc=3
  T5 现役停线负对照：对 sim_report/pex_v27 现役粘连件跑真链结果（tag=a0neg）→ INCOMPLETE，
                且归因栏必须出现「A0/门1 未过」类条目（不能空着说无异常）

合成件全打头 FIXTURE-SYNTHETIC，禁进网表。
"""
import json
import re
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
FIX = os.path.join(HERE, 'selftest_pvt27', 'receipt')
PIPE = os.path.join(HERE, 'm5_pex_pipeline_selftestfixture.json')
GATE = os.path.join(HERE, 'm5_pex_op_gate_selftestfixture.json')
TRAN = os.path.join(HERE, 'm5_pex_tran_selftestfixture.json')
LED_FIX = os.path.join(HERE, 'selftest_pvt27', 'uniform', 'pvt27_ledger.json')
LED_ERR = os.path.join(HERE, 'selftest_pvt27', 'partial', 'pvt27_ledger.json')


def w(p, o):
    json.dump(o, open(p, 'w'), indent=1, ensure_ascii=False)


def run(tag, pipeline, gate, tran, outdir, ledger):
    cmd = [sys.executable, os.path.join(HERE, 'm5_pvt27_receipt.py'), '--tag', tag,
           '--pipeline', pipeline, '--outdir', outdir,
           '--out-json', os.path.join(FIX, '%s.json' % tag),
           '--out-md', os.path.join(FIX, '%s.md' % tag)]
    # op_gate / tran 路径按 tag 推导，故把合成件按 tag 名摆好
    for p, dst in ((gate, os.path.join(HERE, 'm5_pex_op_gate_%s.json' % tag)),
                   (tran, os.path.join(HERE, 'm5_pex_tran_%s.json' % tag))):
        if p and os.path.exists(p):
            shutil.copy(p, dst)
    r = subprocess.run(cmd, capture_output=True, text=True)
    # 合成 tag 的 §4.1-A 表收进自测目录，不留在 m5/ 根下冒充现役件
    sp = os.path.join(HERE, 'drv2_suspicious_%s.json' % tag)
    if os.path.exists(sp):
        shutil.copy(sp, os.path.join(FIX, '%s_suspicious.json' % tag))
        os.remove(sp)
    return r.returncode, (r.stdout or '') + (r.stderr or '')


def main():
    os.makedirs(FIX, exist_ok=True)
    # 合成 pipeline（FIXTURE-SYNTHETIC）
    w(PIPE, {'tag': 'selftestfixture', 'FIXTURE_SYNTHETIC': True, 'cdldir': '', 'stages': {
        'A0_reship_check': {'rc': 0, 'ALL_PASS': True,
                            'criteria_states': {'c1': 'PASS', 'c2': 'PASS', 'c3': 'PASS',
                                                'c4': 'PASS', 'c5': 'PASS', 'c6': 'PASS'}},
        'A_audit': {'HBT_total': 31, 'b_eq_e': 0, 'R_selfloop': 0,
                    'cdl_sha256': {'mix': 'f' * 64, 'drv1': 'e' * 64, 'drv2': 'd' * 64}},
        'B_substitute': {'deck_full': '/FIXTURE/chain_top_tb_v015_1_pex_selftestfixture.sp',
                         'deck_sha256': 'c' * 64, 'deck_op': '/FIXTURE/..._op.sp',
                         'rc': (0, 0)},
        'C_op_gate': {'op_solved': True, 'A0p_max': 1.1e-05, 'gate': 1e-05, 'PASS': True},
        'D_tran_gate': {'CG_dB': 17.4461, 'delta_dB': -0.0004, 'gate_dB': 0.05, 'PASS': True,
                        'tran_raw': '/FIXTURE/pex_selftestfixture_tran.raw'},
        'E_pvt27': {'outdir': '/FIXTURE/pvt27', 'PASS_corners': 27, 'total_corners': 27,
                    'rc': 0, 'elapsed_s': 22600.0}}})
    w(GATE, {'A0p_max': 1.1e-05, 'gate_threshold': 1e-05, 'PASS': True})
    w(TRAN, {'level_gains': {'CG_chain_dB': 17.4461}, 'delta_vs_anchor_dB': -0.0004,
             'anchor_dB': 17.4465, 'gate_dB': 0.05, 'PASS': True})

    outdir_ok = os.path.join(FIX, 'pvt27_ok')
    if os.path.isdir(outdir_ok):
        shutil.rmtree(outdir_ok)
    shutil.copytree(os.path.join(HERE, 'selftest_pvt27', 'uniform'), outdir_ok)

    log = ['# §五 四件套装配器自测 log（合成件，禁进网表）', '']
    fails = []

    def check(name, cond, detail=''):
        log.append('- %s %s %s' % ('✅' if cond else '❌', name, detail))
        if not cond:
            fails.append(name)

    # T1 齐件
    rc1, o1 = run('rcptok', PIPE, GATE, TRAN, outdir_ok, LED_FIX)
    j1 = json.load(open(os.path.join(FIX, 'rcptok.json')))
    check('T1 齐件 → COMPLETE rc=0', rc1 == 0 and j1['status'] == 'COMPLETE',
          '(rc=%d status=%s)' % (rc1, j1['status']))
    check('T1 §五-5 逐角表齐 27 行', len(j1['section2b_corners']) == 27,
          '(%d)' % len(j1['section2b_corners']))
    check('T1 A0′/CG/Δ 均取到数', j1['section2_key_values']['A0p_max_dB'] == 1.1e-05 and
          abs(j1['section2_key_values']['gate2']['CG_PEX_dB'] - 17.4461) < 1e-9)
    check('T1 §4.1-A 表自动补跑并入回执',
          j1['section1_result_paths']['drv2_suspicious']['sha256'] is not None)

    # T2 缺台账
    empty = os.path.join(FIX, 'pvt27_empty')
    os.makedirs(empty, exist_ok=True)
    rc2, _ = run('rcptnoledger', PIPE, GATE, TRAN, empty, None)
    j2 = json.load(open(os.path.join(FIX, 'rcptnoledger.json')))
    check('T2 缺 27 角台账 → INCOMPLETE rc=3',
          rc2 == 3 and j2['status'] == 'INCOMPLETE' and
          any('27 角台账' in m for m in j2['missing']),
          '(rc=%d missing=%s)' % (rc2, [m[:22] for m in j2['missing']][:3]))

    # T3 缺门2
    rc3, _ = run('rcptnotran', PIPE, GATE, None, outdir_ok, LED_FIX)
    j3 = json.load(open(os.path.join(FIX, 'rcptnotran.json')))
    check('T3 缺门2 json → INCOMPLETE rc=3',
          rc3 == 3 and any('门2' in m for m in j3['missing']),
          '(rc=%d)' % rc3)

    # T4 角级残缺
    outdir_err = os.path.join(FIX, 'pvt27_err')
    if os.path.isdir(outdir_err):
        shutil.rmtree(outdir_err)
    shutil.copytree(os.path.join(HERE, 'selftest_pvt27', 'partial'), outdir_err)
    rc4, _ = run('rcptpartial', PIPE, GATE, TRAN, outdir_err, LED_ERR)
    j4 = json.load(open(os.path.join(FIX, 'rcptpartial.json')))
    check('T4 台账在但角级残缺 → INCOMPLETE rc=3',
          rc4 == 3 and any('逐角判读不全' in m for m in j4['missing']),
          '(rc=%d missing=%s)' % (rc4, [m for m in j4['missing'] if '逐角' in m]))
    check('T4 归因栏点出 error 角', any('error 角' in x for x in
          j4['section4_attribution_and_rulings']['attribution']))

    # T5 现役停线负对照（真件，A0 已判不过的链结果）
    r = subprocess.run([sys.executable, os.path.join(HERE, 'm5_pvt27_receipt.py'),
                        '--tag', 'a0neg', '--no-susp',
                        '--out-json', os.path.join(FIX, 'rcpta0neg.json'),
                        '--out-md', os.path.join(FIX, 'rcpta0neg.md')],
                       capture_output=True, text=True)
    j5 = json.load(open(os.path.join(FIX, 'rcpta0neg.json')))
    att = j5['section4_attribution_and_rulings']['attribution']
    check('T5 现役停线态 → INCOMPLETE（不得报 COMPLETE）',
          r.returncode == 3 and j5['status'] == 'INCOMPLETE',
          '(rc=%d status=%s)' % (r.returncode, j5['status']))
    check('T5 归因栏非空且含 A0/门1 类条目',
          len(att) >= 1 and not any(x.startswith('无（') for x in att),
          '(attrib=%s)' % [x[:38] for x in att][:3])

    log.append('')
    log.append('结论：%d/%d 项通过%s' % (8 - len(fails), 8,
                                       '' if not fails else ' —— 未过：%s' % '、'.join(fails)))
    # 合成 tag 的中间件全部收进自测目录，不留在 m5/ 根下冒充现役判读件
    moved = []
    for f in sorted(os.listdir(HERE)):
        if re.match(r'^m5_pex_(pipeline|op_gate|tran)_(rcpt|selftestfixture)', f):
            shutil.move(os.path.join(HERE, f), os.path.join(FIX, f))
            moved.append(f)
    log.append('- 合成中间件收档 %d 件 → %s（防误当现役件）' % (len(moved), FIX))
    lp = os.path.join(HERE, 'pvt27_receipt_selftest.log')
    open(lp, 'w', encoding='utf-8').write('\n'.join(log) + '\n')
    print('\n'.join(log))
    return 1 if fails else 0


if __name__ == '__main__':
    sys.exit(main())
