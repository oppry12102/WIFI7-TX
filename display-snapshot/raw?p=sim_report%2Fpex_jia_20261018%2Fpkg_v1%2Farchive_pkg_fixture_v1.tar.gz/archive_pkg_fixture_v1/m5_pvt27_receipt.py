#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""m5_pvt27_receipt.py — M5 PEX 判读回执**四件套装配器**（runbook v2.6 §五，沿组长 04:44:24Z 格式）

把一键链的产物装配成回执五项（§五 1~5），**只读文件、只搬事实**：
  1. 判读结果 JSON 路径（pipeline / op_gate / tran / pvt27_ledger / drv2_suspicious）
  2. 关键数值：A0′、CG_PEX、Δ vs 锚、逐角 ΔCG 表
  3. 跑件 / deck / raw 的 sha256
  4. 偏差归因与请求裁决项（只填有据可依者；无据即写「无」并列入待裁定，不臆造）
  5. drv2 四组偏置同漂判读（引 §4.1-A 表；若进 B 层，附四组 nref 静态点表与同漂/失配结论）

纪律：**缺件即缺件**。任何应到而无到的产物都进 `missing` 清单，回执标 INCOMPLETE，
绝不以占位数冒充结果；不给未发生的角写数值。

用法：
  python3 m5_pvt27_receipt.py --tag fix [--cdldir <cdl目录>] [--outdir pvt27_fix]
                              [--pipeline <json>] [--suspicious <json>] [--bias-probe <json>]
                              [--no-susp] [--out-json …] [--out-md …]
退出码：0 = COMPLETE；3 = 产出但 INCOMPLETE（带缺件清单）；2 = 无法产出。
"""
import argparse
import hashlib
import json
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
CDL = {'mix': 'pex_mix_v27.cdl', 'drv1': 'pex_drv1_v19.cdl', 'drv2': 'pex_drv2_v19.cdl'}


def sha256(p):
    if not (p and os.path.exists(p)):
        return None
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


def jload(p):
    if not (p and os.path.exists(p)):
        return None
    try:
        return json.load(open(p, encoding='utf-8'))
    except Exception as e:
        return {'__load_error__': str(e)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--tag', default='fix')
    ap.add_argument('--cdldir', default='')
    ap.add_argument('--outdir', default='')
    ap.add_argument('--pipeline', default='')
    ap.add_argument('--suspicious', default='')
    ap.add_argument('--bias-probe', default='')
    ap.add_argument('--no-susp', action='store_true', help='不自动补跑 §4.1-A 表（缺件即列 missing）')
    ap.add_argument('--out-json', default='')
    ap.add_argument('--out-md', default='')
    a = ap.parse_args()

    oj = a.out_json or os.path.join(HERE, 'pvt27_receipt_%s.json' % a.tag)
    om = a.out_md or os.path.join(HERE, 'pvt27_receipt_%s.md' % a.tag)
    p_pipe = a.pipeline or os.path.join(HERE, 'm5_pex_pipeline_%s.json' % a.tag)
    p_gate = os.path.join(HERE, 'm5_pex_op_gate_%s.json' % a.tag)
    p_tran = os.path.join(HERE, 'm5_pex_tran_%s.json' % a.tag)
    p_out = a.outdir or os.path.join(HERE, 'pvt27_%s' % a.tag)
    p_led = os.path.join(p_out, 'pvt27_ledger.json')
    p_susp = a.suspicious or os.path.join(HERE, 'drv2_suspicious_%s.json' % a.tag)
    p_bias = a.bias_probe or os.path.join(HERE, 'drv2_bias_probe_%s.json' % a.tag)

    missing = []
    pipe = jload(p_pipe)
    if pipe is None:
        missing.append('一键链结果 %s' % p_pipe)
    gate = jload(p_gate)
    if gate is None:
        missing.append('门1 判读 %s' % p_gate)
    tran = jload(p_tran)
    if tran is None:
        missing.append('门2 动态对拍 %s' % p_tran)
    led = jload(p_led)
    if led is None:
        missing.append('27 角台账 %s' % p_led)

    # §五-5：A 层第一判据表（缺则补跑；补不出就列 missing，绝不用空表充数）
    susp = jload(p_susp)
    susp_rc = None
    if susp is None and led is not None and not a.no_susp:
        r = subprocess.run([sys.executable, os.path.join(HERE, 'm5_drv2_suspicious.py'),
                            '--ledger', p_led, '--tag', a.tag],
                           capture_output=True, text=True)
        susp_rc = r.returncode
        susp = jload(p_susp)
    if susp is None or not (susp or {}).get('ALL_OK'):
        missing.append('§4.1-A 逐角 drv2_suspicious 表 %s' % p_susp)

    bias = jload(p_bias)
    if bias is None:
        bias_state = '未跑（§4.1-B 仅对置位角事后跑；是否跑等组长裁定）'
    else:
        bias_state = ('已跑：%s' % bias.get('verdict', '见 JSON')) if bias.get('ALL_OK') \
            else ('跑而未成：%s' % (bias.get('reason') or bias.get('__load_error__') or '未知'))

    # ── 关键数值（全部来自文件；取不到即 None，不填占位）──────────────────────
    st = (pipe or {}).get('stages') or {}
    c_stage = st.get('C_op_gate') or {}
    d_stage = st.get('D_tran_gate') or {}
    e_stage = st.get('E_pvt27') or {}
    a0_stage = st.get('A0_reship_check') or {}
    key = {
        'A0_reship_ALL_PASS': a0_stage.get('ALL_PASS'),
        'A0_criteria_states': a0_stage.get('criteria_states'),
        'A_HBT_total': (st.get('A_audit') or {}).get('HBT_total'),
        'A_b_eq_e': (st.get('A_audit') or {}).get('b_eq_e'),
        'A_R_selfloop': (st.get('A_audit') or {}).get('R_selfloop'),
        'A0p_max_dB': c_stage.get('A0p_max', (gate or {}).get('A0p_max')),
        'gate1': {'PASS': c_stage.get('PASS'), 'threshold': c_stage.get('gate',
                    (gate or {}).get('gate_threshold')), 'op_solved': c_stage.get('op_solved')},
        'gate2': {'PASS': d_stage.get('PASS'), 'gate_dB': d_stage.get('gate_dB',
                    (tran or {}).get('gate_dB')), 'CG_PEX_dB': d_stage.get('CG_dB',
                    ((tran or {}).get('level_gains') or {}).get('CG_chain_dB')),
                  'delta_vs_anchor_dB': d_stage.get('delta_dB', (tran or {}).get('delta_vs_anchor_dB')),
                  'anchor_dB': (tran or {}).get('anchor_dB', 17.4465)},
        'pvt27': {'total_corners': e_stage.get('total_corners') or len((led or {}).get('corners') or {}),
                  'PASS_corners': e_stage.get('PASS_corners'),
                  'rc': e_stage.get('rc'), 'elapsed_s': e_stage.get('elapsed_s')},
        'drv2_suspicious': {
            'count': (susp or {}).get('summary', {}).get('drv2_suspicious_count'),
            'hard_flag_count': (susp or {}).get('summary', {}).get('hard_flag_count'),
            'typ_corner_flagged': (susp or {}).get('summary', {}).get('typ_corner_flagged'),
            'k_sensitivity': (susp or {}).get('summary', {}).get('k_sensitivity'),
            'seg_anomalies': (susp or {}).get('summary', {}).get('seg_anomalies'),
            'rule': (susp or {}).get('rule'),
        },
    }

    # 逐角 ΔCG 表
    corners_tbl = []
    for nm, c in sorted(((led or {}).get('corners') or {}).items()):
        sj = None
        pj = os.path.join(p_out, nm, 'parse.json')
        if os.path.exists(pj):
            pdd = jload(pj) or {}
            sj = {'delta_dB': pdd.get('delta_vs_anchor_dB'), 'PASS': pdd.get('PASS'),
                  'CG_mix_dB': (pdd.get('level_gains') or {}).get('CG_mix_dB'),
                  'CG_drv1_dB': (pdd.get('level_gains') or {}).get('CG_drv1_dB'),
                  'CG_drv2_dB': (pdd.get('level_gains') or {}).get('CG_drv2_dB')}
        srow = next((r for r in (susp or {}).get('rows', []) if r.get('corner') == nm), None)
        corners_tbl.append({
            'corner': nm, 'CG_dB': c.get('CG_dB'), 'delta_dB': c.get('delta_dB'),
            'PASS': c.get('PASS'), 'error': c.get('error'),
            'drv2_suspicious': (srow or {}).get('drv2_suspicious'),
            'flag_basis': (srow or {}).get('flag_basis'),
            'abs_dev_neighbor_dB': (srow or {}).get('abs_dev_neighbor_dB'),
            'z_global': (srow or {}).get('z_global'), 'z_lib': (srow or {}).get('z_lib'),
            'z_neighbor': (srow or {}).get('z_neighbor'),
            'from_parse_json': sj,
            'sha256': c.get('sha256'),
        })

    # ── sha256（跑件/deck/raw）──────────────────────────────────────────────
    shas = {'cdl': {}, 'artifacts': {}}
    cdlsrc = a.cdldir or (pipe or {}).get('cdldir') or ''
    pipe_shas = ((st.get('A_audit') or {}).get('cdl_sha256') or {})
    for k, fn in CDL.items():
        shas['cdl'][k] = {'file': fn, 'sha256': pipe_shas.get(k) or (sha256(os.path.join(cdlsrc, fn)) if cdlsrc else None)}
    b_stage = st.get('B_substitute') or {}
    c_stage_r = st.get('C_op_gate') or {}
    d_stage_r = st.get('D_tran_gate') or {}
    art = (('deck_full', b_stage.get('deck_full')), ('deck_op', b_stage.get('deck_op')),
           ('tran_raw', d_stage_r.get('tran_raw')),
           ('op_raw', os.path.join(HERE, 'pex_%s_op.raw' % a.tag)),
           ('op_gate_json', p_gate), ('tran_parse_json', p_tran),
           ('pvt27_ledger', p_led), ('drv2_suspicious_json', p_susp),
           ('bias_probe_json', p_bias))
    for name, p in art:
        shas['artifacts'][name] = {'path': p, 'sha256': sha256(p)}
    shas['artifacts']['deck_full']['sha256'] = b_stage.get('deck_sha256') or \
        shas['artifacts']['deck_full']['sha256']

    # ── 偏差归因与请求裁决项（只写有据者）────────────────────────────────────
    attrib, rulings = [], []
    if (pipe or {}).get('stages', {}).get('A0_reship_check', {}).get('rc'):
        attrib.append('A0 裁定五六判据未全过 → 停线（见 cdl_reship_check_%s.md）' % a.tag)
    if c_stage and not c_stage.get('PASS'):
        attrib.append('门1 未过：%s' % (c_stage.get('stop') or 'A0′ 超门'))
    if d_stage and not d_stage.get('PASS'):
        attrib.append('门2 未过：ΔCG=%s dB（门 %s）' % (d_stage.get('delta_dB'), d_stage.get('gate_dB')))
    hard_c = [t['corner'] for t in corners_tbl if t.get('drv2_suspicious') and t.get('flag_basis') == 'hard_gate']
    if hard_c:
        attrib.append('角级硬置位（|ΔCG|>0.05 dB）：%s' % '、'.join(hard_c))
    seg = (susp or {}).get('summary', {}).get('seg_anomalies') or []
    if seg:
        attrib.append('分段增益异常 %d 处（seg_note，未并入置位口径）' % len(seg))
    err_c = [t['corner'] for t in corners_tbl if t.get('error')]
    if err_c:
        attrib.append('跑批 error 角 %d 个：%s' % (len(err_c), '、'.join(err_c)))
    if not attrib:
        attrib.append('无（门1/门2 与逐角判读均未触发归因项）')
    if susp:
        rulings.append('§4.1-A 置位口径（臂A abs 阈值 / 臂B z 阈值）待裁定：'
                       '表内已给二维灵敏度网格，未据此自定口径或自动触发 C 层')
        if (susp.get('summary') or {}).get('typ_corner_flagged'):
            rulings.append('typ 角已置位 → §4.1-C 再议触发成立，等裁定是否跑 C 层/扩 save')
    for m in missing:
        rulings.append('缺件待补：%s' % m)

    complete = not missing and bool(led)
    if led:
        n_ok = sum(1 for t in corners_tbl if t.get('delta_dB') is not None and not t.get('error'))
        if n_ok < len(corners_tbl):
            missing.append('逐角判读不全：%d/%d 角有 ΔCG' % (n_ok, len(corners_tbl)))
            complete = False

    out = {
        'receipt_version': 'v1（§五 五项，2026-10-18 建）',
        'tag': a.tag, 'status': 'COMPLETE' if complete else 'INCOMPLETE',
        'generated_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'section1_result_paths': {
            'pipeline': {'path': p_pipe, 'sha256': sha256(p_pipe)},
            'op_gate': {'path': p_gate, 'sha256': sha256(p_gate)},
            'tran_parse': {'path': p_tran, 'sha256': sha256(p_tran)},
            'pvt27_ledger': {'path': p_led, 'sha256': sha256(p_led)},
            'drv2_suspicious': {'path': p_susp, 'sha256': sha256(p_susp)},
            'bias_probe': {'path': p_bias, 'sha256': sha256(p_bias), 'state': bias_state},
            'suspicious_autogen_rc': susp_rc,
        },
        'section2_key_values': key,
        'section2b_corners': corners_tbl,
        'section3_sha256': shas,
        'section4_attribution_and_rulings': {'attribution': attrib, 'rulings_needed': rulings},
        'section5_drv2_bias_read': {
            'layer_A_table': p_susp if susp and susp.get('ALL_OK') else None,
            'flagged_corners': [t['corner'] for t in corners_tbl if t.get('drv2_suspicious')],
            'typ_corner_flagged': (susp or {}).get('summary', {}).get('typ_corner_flagged'),
            'reeval_trigger_C_layer': (susp or {}).get('summary', {}).get('reeval_trigger_C_layer'),
            'layer_B_state': bias_state,
            'layer_B_table': bias if bias else None,
            'spread_criterion': '§4.1-B 组长备案：四组 V(nref) 差 <1 mV → 偏置公共模同漂；'
                                '离散大 → 组间失配（本脚本用 1.0 mV，不自设）',
        },
        'missing': missing,
        'discipline': ('本回执只搬文件里有的事实：缺件即列 missing 且标 INCOMPLETE，'
                       '不填占位数、不替未跑的角写数值、不自定置位口径。'),
    }
    json.dump(out, open(oj, 'w'), indent=1, ensure_ascii=False)

    # ── md ────────────────────────────────────────────────────────────────
    L = ['# M5 PEX 判读回执（tag=%s，§五 五项）' % a.tag, '',
         '- 状态：**%s**（生成 %s）' % (out['status'], out['generated_utc']),
         '- %s' % out['discipline'], '']
    if missing:
        L.append('## 缺件清单')
        L.append('')
        for m in missing:
            L.append('- %s' % m)
        L.append('')
    L.append('## §五-1 判读结果 JSON 路径')
    L.append('')
    L.append('| 项 | 路径 | sha256 |')
    L.append('|---|---|---|')
    for k, v in out['section1_result_paths'].items():
        if isinstance(v, dict) and 'path' in v:
            L.append('| %s | `%s` | `%s` |' % (k, v['path'], (v.get('sha256') or '—')[:16]))
    L.append('')
    L.append('## §五-2 关键数值')
    L.append('')
    L.append('- A0 裁定五六判据全过：**%s**（%s）' % (key['A0_reship_ALL_PASS'],
             '、'.join('%s=%s' % (a_, b_) for a_, b_ in (key['A0_criteria_states'] or {}).items()) or '—'))
    L.append('- A 静态审计：HBT %s 件 / b==e 粘连 %s 件 / R 自环 %s 件'
             % (key['A_HBT_total'], key['A_b_eq_e'], key['A_R_selfloop']))
    L.append('- 门1（.op）：A0′ = %s dB，门 %s，PASS=%s'
             % (key['A0p_max_dB'], key['gate1']['threshold'], key['gate1']['PASS']))
    L.append('- 门2（动态）：CG_PEX = %s dB，Δ vs 锚 %s = %s dB，门 %s dB，PASS=%s'
             % (key['gate2']['CG_PEX_dB'], key['gate2']['anchor_dB'],
                key['gate2']['delta_vs_anchor_dB'], key['gate2']['gate_dB'], key['gate2']['PASS']))
    L.append('- 27 角：PASS %s / 总 %s（rc=%s，用时 %s s）'
             % (key['pvt27']['PASS_corners'], key['pvt27']['total_corners'],
                key['pvt27']['rc'], key['pvt27']['elapsed_s']))
    L.append('')
    if corners_tbl:
        L.append('### 逐角 ΔCG 表（§五-2）')
        L.append('')
        L.append('| 角 | CG(dB) | ΔCG(dB) | PASS | drv2_suspicious | 依据 | 对邻角偏离(dB) | z_glob | z_lib | z_nb |')
        L.append('|---|---|---|---|---|---|---|---|---|---|')
        for t in corners_tbl:
            f = lambda x, n=5: ('%+.*f' % (n, x)) if isinstance(x, (int, float)) else '—'
            L.append('| %s | %s | %s | %s | %s | %s | %s | %s | %s | %s |' % (
                t['corner'], f(t.get('CG_dB')), f(t.get('delta_dB')), t.get('PASS'),
                '**置位**' if t.get('drv2_suspicious') else '—', t.get('flag_basis') or '—',
                f(t.get('abs_dev_neighbor_dB')), f(t.get('z_global'), 2), f(t.get('z_lib'), 2),
                f(t.get('z_neighbor'), 2)))
        L.append('')
    L.append('## §五-3 sha256')
    L.append('')
    L.append('| 件 | 文件 | sha256 |')
    L.append('|---|---|---|')
    for k, v in shas['cdl'].items():
        L.append('| cdl.%s | %s | `%s` |' % (k, v['file'], v['sha256'] or '—'))
    for k, v in shas['artifacts'].items():
        L.append('| %s | `%s` | `%s` |' % (k, os.path.basename(v['path'] or '—'), v['sha256'] or '—'))
    L.append('')
    L.append('## §五-4 偏差归因与请求裁决项')
    L.append('')
    for x in attrib:
        L.append('- 归因：%s' % x)
    for x in rulings:
        L.append('- **请裁定/待补**：%s' % x)
    L.append('')
    L.append('## §五-5 drv2 四组偏置同漂判读（§4.1）')
    L.append('')
    L.append('- A 层第一判据表：%s' % (p_susp if susp and susp.get('ALL_OK') else '**缺**（见缺件清单）'))
    L.append('- 逐角置位角：%s' % ('、'.join(out['section5_drv2_bias_read']['flagged_corners']) or '无'))
    L.append('- typ 角置位：**%s**' % out['section5_drv2_bias_read']['typ_corner_flagged'])
    L.append('- 再议触发（§4.1-C）：%s' % (out['section5_drv2_bias_read']['reeval_trigger_C_layer'] or '—'))
    L.append('- B 层：%s' % bias_state)
    L.append('- 判读准则（组长备案）：%s' % out['section5_drv2_bias_read']['spread_criterion'])
    L.append('')
    open(om, 'w', encoding='utf-8').write('\n'.join(L) + '\n')

    print('[receipt] %s：%s（缺件 %d）' % (a.tag, out['status'], len(missing)))
    print('[receipt] %s / %s' % (om, oj))
    return 0 if complete else (3 if (led or pipe or gate or tran) else 2)


if __name__ == '__main__':
    sys.exit(main())
