# 常备夹具包 v1（**九件**）— 供组长侧本地独立复跑

来源：`sow6/m5/selftest_pvt27/<态>/pvt27_ledger.json` ×6 + `sow6/m5/m5_pvt27_receipt.py` ×1
　　　+ **两个 driver**（`selftest_drv2_suspicious_v4.py`、`selftest_pvt27_receipt.py`）×2
装包：`sow6/m5/archive_pkg_fixture_v1/`，清单 `MANIFEST.sha256`（sha256 逐件）。
登记依据：b7a0 2026-10-18T04:00:27Z 信第四节（非阻塞、随下版顺手投 8510 `design/sow6/` 归档）；
**04:04:06Z 信第一节裁定「①并入——下批归档升九件」**，两 driver 已入包（本轮仍**不投递**，随下版 A0→E 链同批走）。
**04:08:07Z 信裁定十：维持九件不升十件**（driver 9 完整 8/8 须原生位置；包定位＝七态夹具 + driver 8 一键复跑，详见 §三）。
**纪律：合成夹具禁进网表**（沿用 `selftest_drv2_suspicious_v4.py` docstring 原话）。

## 〇、九件清单（与 `MANIFEST.sha256` 逐行对应）

| # | 件 | 角色 |
|---|---|---|
| 1 | `selftest_pvt27/uniform/pvt27_ledger.json` | 台账·uniform 态 |
| 2 | `selftest_pvt27/partial/pvt27_ledger.json` | 台账·partial 态 |
| 3 | `selftest_pvt27/segdrift/pvt27_ledger.json` | 台账·segdrift 态 |
| 4 | `selftest_pvt27/jumpdet/pvt27_ledger.json` | 台账·jumpdet 态 |
| 5 | `selftest_pvt27/outlier1/pvt27_ledger.json` | 台账·outlier1 态 |
| 6 | `selftest_pvt27/outlier2/pvt27_ledger.json` | 台账·outlier2 态 |
| 7 | `m5_pvt27_receipt.py` | receipt 装配器（管线侧） |
| 8 | `selftest_drv2_suspicious_v4.py` | driver·可疑判读器五态自测 |
| 9 | `selftest_pvt27_receipt.py` | driver·receipt 装配器自测 |

## 一、七态台账映射（判读器 `m5_drv2_suspicious.py`）

| 态 | 夹具 ledger | 构造意图 | 预期 exit |
|---|---|---|---|
| w4_uniform | `selftest_pvt27/uniform/pvt27_ledger.json` | 全均匀：零置位 | 0 |
| w4_outlier1 | `selftest_pvt27/outlier1/pvt27_ledger.json` | 单角**硬置位**（\|ΔCG\|>0.05） | 1 |
| w4_outlier2 | `selftest_pvt27/outlier2/pvt27_ledger.json` | 单角候选置位（非硬） | 0 |
| w4_segdrift | `selftest_pvt27/segdrift/pvt27_ledger.json` | 段间漂移（seg_note） | 0 |
| w4_partial | `selftest_pvt27/partial/pvt27_ledger.json` | 角级残缺（25/27 可判） | 0 |
| w4_neg | `selftest_pvt27/uniform/pvt27_ledger.json` + `--k 0.1 --abs-thr 0.0` | 阈值全开负对照（**复用 uniform**，故六台账对七态） | 0 |
| w4_jumpdet | `selftest_pvt27/jumpdet/pvt27_ledger.json` | 跳变检出（`jump_any=True`） | 0 |

单件复跑（把 `<判读器>` 换成待验脚本路径）：

```
python3 <判读器>.py --ledger selftest_pvt27/<态>/pvt27_ledger.json --out-json /tmp/<态>.json --out-md /tmp/<态>.md
python3 <判读器>.py --ledger selftest_pvt27/uniform/pvt27_ledger.json --k 0.1 --abs-thr 0.0   # neg 态
```

口径级（非文案）改动的验收建议：对改前/改后**同参数**跑上表七条，比 exit + `summary` 关键字段；
`jumpdet` 必看 `summary.sensitivity_jump_verdict`（jump_any / 阈值 / 动作串）。

## 二、receipt 装配器 `m5_pvt27_receipt.py`

参数：`--tag --cdldir --outdir --pipeline --suspicious --bias-probe --no-susp --out-json --out-md`
回执四件套口径（rcptok / rcptnoledger / rcptpartial / rcptnotran）按缺件/残缺/无 ledger 分流，
各态期望产物与本包外既有 `receipt/` 夹具一致；装包**不含** `receipt/` 产物目录（避免重复归档）。

## 三、两个 driver 的用法（04:04:06Z 裁定并入）

### driver 8：`selftest_drv2_suspicious_v4.py` —— **可在本包内独立跑通**

```bash
python3 selftest_drv2_suspicious_v4.py --outdir /tmp/d8 \
        --script <m5_drv2_suspicious.py 的路径>       # ← 必须显式给 --script
```

**注意**：该 driver 的 `--script` 默认值是**同目录**下的 `m5_drv2_suspicious.py`，
而判读器**不在本包内**，故必须显式传 `--script`（漏传则七态全 ❌、退出码 1 —— 响亮失败，不会静默算过）。
其 CASES 即上表七态（与「六台账对七态」逐条对齐）；产物 `<outdir>/state_table.json` 记
`all_exit_as_expected` 与判读器 `script_sha256`（现役 = `19b26837…`）。
**我侧自测：解包目录实跑 exit=0、七态 7/7 ✅。**

### driver 9：`selftest_pvt27_receipt.py` —— **本包内单跑只得 4/8（依赖在包外）**

```bash
python3 selftest_pvt27_receipt.py     # 无参数
```

它在原生位置实跑 **8/8 ✅**（已验，非死文件），但在**本包解包目录单跑 4/8、exit=1**，两个外部依赖：

| 失败项 | 根因 | 缺什么 |
|---|---|---|
| T1 齐件 → COMPLETE ／ T1 §4.1-A 表自动补跑 | 装配器要同级 `m5_drv2_suspicious.py` 补跑逐角表 | **判读器**（本包未含，在 `m5/` 根下） |
| T5 现役停线态 ／ T5 归因栏非空 | 对**真件**跑负对照，需现役粘连件目录 | **`sim_report/pex_v27` 真件**（合成夹具不能替代，禁进网表纪律） |

T2/T3/T4（缺台账／缺门2／角级残缺 → INCOMPLETE rc=3）在包内**照常通过** 3/3 ✅。
三个 `m5_pex_*selftestfixture.json` 由 driver 9 **自生成**，无需随包。

> **driver 9 完整 8/8 须原生位置**（同级判读器 `m5_drv2_suspicious.py` + `sim_report/pex_v27` 真件在位）；
> **包内角色 = 存档 + `py_compile` 证明**。

**裁定十（b7a0 2026-10-18T04:08:07Z）留档：维持九件，不升十件。**
- 理由一：真件负对照天然不可入包（真件是**判读对象**不是夹具，同「合成夹具禁进网表」纪律）
  ⇒「包内 8/8」目标本身不可达，升十件花成本买不到目标；
- 理由二：判读器 `19b26837` 是**现役验收锚**、下版要动 checker 第 10 行 docstring
  ⇒ 包内复制 = 制造必然陈旧的第二份拷贝，违单源真值；
- 包定位收敛为「**七态夹具 + driver 8 一键复跑**」自足件
  （7/7 exit 全对齐 + `state_table.json` 回读 `19b26837` 交叉对上，可用性已证）；
  driver 9 在包内 = 存档 + `py_compile`。

## 四、组长侧到包验收口径（04:04:06Z 信第一节预备案，我侧已按此自测）

1. 解包 → `MANIFEST.sha256` 逐行回验；
2. 抽一态实跑（**jumpdet 优先**）；
3. 两 driver `py_compile` + 七态抽一。

**MANIFEST 带 bytes 列，不能直接喂 `sha256sum -c`**，请剥列：

```bash
grep -v '^#' MANIFEST.sha256 | awk '{print $2"  "$3}' | sha256sum -c -
```

**我侧九件版自测结果（04:05Z，解包目录）**：① MANIFEST **10/10 OK**；
② 三脚本 `py_compile` PASS；③ jumpdet 实跑 exit=0、`jump_any=true`（与预期一致）；
④ 七态抽一 **7/7 exit 全对齐**（outlier1=1 硬置位、partial=25/27、neg 全开 27 候选）；
⑤ driver 8 带 `--script` 实跑 exit=0、七态 7/7；⑥ driver 9 包内 4/8（见 §三，依赖在包外）。

—— fde9（WiFi7-TX 仿真验证）装包 2026-10-18T04:1xZ（九件版；04:04Z 裁定①并入、04:08Z 裁定十维持九件，仅 README 补载）
