#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""selftest_drv2_suspicious_v4.py — m5_drv2_suspicious.py 七态回归（措辞修正前后对拍用）

用法:
  python3 selftest_drv2_suspicious_v4.py --outdir <产物目录> [--script <被判读脚本路径>]

七态 = §4.1-A 五态合成台账 + 阈值负对照 + 跳变检出合成件(jumpdet)。
产物: <outdir>/drv2_suspicious_<tag>.{json,md} + state_table.json（七态 exit/stdout/关键字段）。
合成件禁进网表（仅判读器自测）。
"""
import argparse
import json
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
CASES = [
    # (tag, ledger, extra args, 说明, 预期 exit)
    ('w4_uniform', 'selftest_pvt27/uniform/pvt27_ledger.json', [], '全均匀：零置位', 0),
    ('w4_outlier1', 'selftest_pvt27/outlier1/pvt27_ledger.json', [], '单角硬置位（|ΔCG|>0.05）', 1),
    ('w4_outlier2', 'selftest_pvt27/outlier2/pvt27_ledger.json', [], '单角候选置位（非硬）', 0),
    ('w4_segdrift', 'selftest_pvt27/segdrift/pvt27_ledger.json', [], '段间漂移（seg_note）', 0),
    ('w4_partial', 'selftest_pvt27/partial/pvt27_ledger.json', [], '角级残缺（25/27 可判）', 0),
    ('w4_neg', 'selftest_pvt27/uniform/pvt27_ledger.json',
     ['--k', '0.1', '--abs-thr', '0.0'], '负对照：阈值全开', 0),
    ('w4_jumpdet', 'selftest_pvt27/jumpdet/pvt27_ledger.json', [], '跳变检出（jump_any=True）', 0),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--outdir', required=True)
    ap.add_argument('--script', default=os.path.join(HERE, 'm5_drv2_suspicious.py'))
    a = ap.parse_args()
    out = a.outdir
    os.makedirs(out, exist_ok=True)

    rows, rc_all = [], 0
    for tag, ledger, extra, desc, exp in CASES:
        cmd = [sys.executable, a.script, '--ledger', os.path.join(HERE, ledger),
               '--tag', tag] + extra
        p = subprocess.run(cmd, cwd=HERE, capture_output=True, text=True)
        j = os.path.join(HERE, 'drv2_suspicious_%s.json' % tag)
        m = os.path.join(HERE, 'drv2_suspicious_%s.md' % tag)
        row = {'tag': tag, 'desc': desc, 'cmd': ' '.join(
            ['python3'] + [c.replace(HERE + '/', '') for c in cmd[1:]]),
            'exit': p.returncode, 'expected_exit': exp,
            'exit_ok': p.returncode == exp,
            'stdout': p.stdout.strip().splitlines()}
        if os.path.exists(j):
            shutil.copy2(j, os.path.join(out, os.path.basename(j)))
            d = json.load(open(j))
            sv = d.get('summary', {}).get('sensitivity_jump_verdict', {})
            row['jump_any'] = sv.get('jump_any')
            row['action'] = sv.get('action')
            row['hard_n'] = d.get('summary', {}).get('hard_flag_n')
            row['cand_n'] = d.get('summary', {}).get('cand_n')
            row['action_md_tail'] = [
                l for l in open(m, encoding='utf-8').read().splitlines()
                if '跳变敏感性' in l]
        else:
            row['json_missing'] = True
        if os.path.exists(m):
            shutil.copy2(m, os.path.join(out, os.path.basename(m)))
        rows.append(row)
        if not row['exit_ok']:
            rc_all = 1
        print('[%s] exit=%d(期望%d)%s | %s' % (tag, p.returncode, exp,
              ' ✅' if row['exit_ok'] else ' ❌', desc))

    st = {'script': a.script, 'script_sha256': sha(a.script),
          'n_cases': len(CASES), 'all_exit_as_expected': rc_all == 0, 'cases': rows}
    with open(os.path.join(out, 'state_table.json'), 'w', encoding='utf-8') as f:
        json.dump(st, f, ensure_ascii=False, indent=2)
    print('七态 exit 全部如预期: %s' % ('YES' if rc_all == 0 else 'NO'))
    return rc_all


def sha(p):
    import hashlib
    return hashlib.sha256(open(p, 'rb').read()).hexdigest()


if __name__ == '__main__':
    raise SystemExit(main())
